/*
 * sens.c
 *
 *  Created on: Jan 31, 2025
 *      Author: BaracchiF
 */

#include "sys.h"
#include "tmr.h"
#include "sens.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

u8	sens_edge;

/* Private function prototypes -----------------------------------------------*/
/* Public function prototypes ------------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
* Function Name  : SENS_Init
* Description    : None.
* Input          : None.
* Output         : None.
* Return         : None
*******************************************************************************/

void	SENS_Init(void)
{
	GPIO_InitTypeDef	pin;
	NVIC_InitTypeDef	nvic;
	EXTI_InitTypeDef	exti;

  RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO | RCC_APB2Periph_GPIOC, ENABLE);

  pin.GPIO_Pin = GPIO_Pin_1;
  pin.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  pin.GPIO_Speed = GPIO_Speed_30MHz;
  GPIO_Init(GPIOC, &pin);

  GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource1);

  exti.EXTI_Line = EXTI_Line1;
  exti.EXTI_LineCmd = ENABLE;
  exti.EXTI_Mode = EXTI_Mode_Interrupt;
  exti.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
  EXTI_Init(&exti);

  nvic.NVIC_IRQChannel = EXTI7_0_IRQn;
  nvic.NVIC_IRQChannelPreemptionPriority = 1;
  nvic.NVIC_IRQChannelSubPriority = 0;
  nvic.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&nvic);

}

/*******************************************************************************
* Function Name  : SENS_Irq
* Description    : None.
* Input          : None.
* Output         : None.
* Return         : None
*******************************************************************************/

void	SENS_Irq(void)
{
  if(EXTI_GetITStatus(EXTI_Line1) != RESET)
  {
  	sens_edge = 1;
    EXTI_ClearITPendingBit(EXTI_Line1);
  }
}

/*******************************************************************************
* Function Name  : SENS_Read
* Description    : None.
* Input          : None.
* Output         : None.
* Return         : None
*******************************************************************************/

u8		SENS_Read(void)
{
	u8 pulse = sens_edge;
	sens_edge = 0;

	return (pulse);
}

/***** end of file *****/

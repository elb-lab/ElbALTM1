/*
 * sys.h
 *
 *  Created on: May 8, 2023
 *      Author: BaracchiF
 */

#ifndef _SYS_H_
#define _SYS_H_

#include "ch32v_mcu.h"
#include "ch32v_pin.h"
#include "tmr.h"

#endif /* _SYS_H_ */

/*
 * ch32v_mcu.h
 *
 *  Created on: May 8, 2023
 *      Author: BaracchiF
 */

#ifndef _CH32V_MCU_H_
#define _CH32V_MCU_H_

#include "ch32x035.h"

#endif /* _CH32V_MCU_H_ */

/*
 * dLed.h
 *
 *  Created on: Jan 31, 2025
 *      Author: BaracchiF
 */

#ifndef _DLED_H_
#define _DLED_H_

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
/* Typedef -------------------------------------------------------------------*/
/* Macro ---------------------------------------------------------------------*/
/* Defines -------------------------------------------------------------------*/

#define NR_LED				9

/* functions -----------------------------------------------------------------*/

void	DLED_Init(void);
void	DLED_Service(void);
void	DLED_SetIntensity(u8 led, u8 intensity);
void	DLED_Disable(void);
void	DLED_Enable(void);

#ifdef __cplusplus
}
#endif


#endif /* _DLED_H_ */

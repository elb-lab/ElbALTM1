/*
 * dLed.c
 *
 *  Created on: Jan 31, 2025
 *      Author: BaracchiF
 */

/* Includes ------------------------------------------------------------------*/
#include "sys.h"
#include "tmr.h"
#include "dLed.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

u8	dled_buff[NR_LED];

/* Private function prototypes -----------------------------------------------*/
/* Public function prototypes ------------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
* Function Name  : DLED_Init
* Description    : None.
* Input          : None.
* Output         : None.
* Return         : None
*******************************************************************************/
static
void	__configure_NRST_pin_as_IO__(void)
{
  FLASH_Unlock();

	FLASH_UserOptionByteConfig(
			OB_IWDG_SW,
			OB_STDBY_NoRST,
			OB_RST_NoEN,
			OB_PowerON_Start_Mode_USER);

	FLASH_Lock();
}

/*******************************************************************************
* Function Name  : DLED_Init
* Description    : None.
* Input          : None.
* Output         : None.
* Return         : None
*******************************************************************************/

void	DLED_Init(void)
{
	GPIO_InitTypeDef	pin;
	RCC_ClocksTypeDef	clk;
	TIM_TimeBaseInitTypeDef	tim;
	TIM_OCInitTypeDef	pwm;
	DMA_InitTypeDef		dma = {0};

  for (u16 i=0; i<sizeof(dled_buff); i++)
  	dled_buff[i] = 0;

  /* clocks initializations */
  RCC_ClearFlag();
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | \
												 RCC_APB2Periph_GPIOC | \
												 RCC_APB2Periph_GPIOD | \
												 RCC_APB2Periph_TIM1 | \
												 RCC_APB2Periph_AFIO,
												 ENABLE);
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

  __configure_NRST_pin_as_IO__();

  /* pin output init. */
  pin.GPIO_Pin = GPIO_Pin_1;
  pin.GPIO_Mode = GPIO_Mode_AF_PP;
  pin.GPIO_Speed = GPIO_Speed_30MHz;
  GPIO_Init(GPIOA, &pin);
  pin.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_3 | GPIO_Pin_4;
  GPIO_Init(GPIOC, &pin);
  pin.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_7;
  GPIO_Init(GPIOD, &pin);

  /* Configurazione pin con PWM software */
  GPIO_SetBits(PC5);
  pin.GPIO_Mode = GPIO_Mode_Out_PP;
  pin.GPIO_Pin = GPIO_Pin_5;
  GPIO_Init(GPIOC, &pin);

  /* Timer base init. */
  RCC_GetClocksFreq(&clk);
  tim.TIM_Prescaler = (uint16_t)(clk.HCLK_Frequency / 1000000) - 1;
  tim.TIM_ClockDivision = TIM_CKD_DIV1;
  tim.TIM_CounterMode = TIM_CounterMode_Up;
  tim.TIM_Period = 100;
  tim.TIM_RepetitionCounter = 0;
  TIM_TimeBaseInit(TIM1, &tim);
  TIM_TimeBaseInit(TIM2, &tim);

  TIM_DMACmd(TIM1, TIM_DMA_Update, ENABLE);
  TIM_DMACmd(TIM2, TIM_DMA_Update, ENABLE);

	/* PWM Output Init. */
  pwm.TIM_OCIdleState = TIM_OCIdleState_Reset;
	pwm.TIM_OCMode = TIM_OCMode_PWM2;
	pwm.TIM_OCNIdleState = TIM_OCNIdleState_Reset;
	pwm.TIM_OCNPolarity = TIM_OCNPolarity_High;
	pwm.TIM_OCPolarity = TIM_OCPolarity_High;
	pwm.TIM_OutputNState = TIM_OutputNState_Disable;
	pwm.TIM_OutputState = TIM_OutputState_Enable;
	pwm.TIM_Pulse = 0;
	TIM_OC1Init(TIM1, &pwm);
	TIM_OC2Init(TIM1, &pwm);
	TIM_OC3Init(TIM1, &pwm);
	TIM_OC4Init(TIM1, &pwm);
	TIM_OC1Init(TIM2, &pwm);
	TIM_OC2Init(TIM2, &pwm);
	TIM_OC3Init(TIM2, &pwm);
	TIM_OC4Init(TIM2, &pwm);

	TIM_OC1PreloadConfig(TIM1, TIM_OCPreload_Enable);
	TIM_OC2PreloadConfig(TIM1, TIM_OCPreload_Enable);
	TIM_OC3PreloadConfig(TIM1, TIM_OCPreload_Enable);
	TIM_OC4PreloadConfig(TIM1, TIM_OCPreload_Enable);
	TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Enable);
	TIM_OC2PreloadConfig(TIM2, TIM_OCPreload_Enable);
	TIM_OC3PreloadConfig(TIM2, TIM_OCPreload_Enable);
	TIM_OC4PreloadConfig(TIM2, TIM_OCPreload_Enable);

  TIM_CtrlPWMOutputs(TIM1, ENABLE);
  TIM_CtrlPWMOutputs(TIM2, ENABLE);

  TIM_ARRPreloadConfig(TIM1, ENABLE);
  TIM_ARRPreloadConfig(TIM2, ENABLE);

  /* DMA x TIM1 */
  dma.DMA_BufferSize = 4;
	dma.DMA_DIR = DMA_DIR_PeripheralDST;
	dma.DMA_M2M = DMA_M2M_Disable;
	dma.DMA_MemoryBaseAddr = (u32)&dled_buff[0];
	dma.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
	dma.DMA_MemoryInc = DMA_MemoryInc_Enable;
	dma.DMA_Mode = DMA_Mode_Circular;
	dma.DMA_PeripheralBaseAddr = (u32)&TIM1->CH1CVR;
	dma.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Word;
	dma.DMA_PeripheralInc = DMA_PeripheralInc_Enable;
	dma.DMA_Priority = DMA_Priority_Low;
  DMA_Init(DMA1_Channel5, &dma);
  /* DMA x TIM1 */
	dma.DMA_MemoryBaseAddr = (u32)&dled_buff[4];
	dma.DMA_PeripheralBaseAddr = (u32)&TIM2->CH1CVR;
  DMA_Init(DMA1_Channel2, &dma);

  DMA_Cmd(DMA1_Channel5, ENABLE);		// DMA x UPDATE on TIM1
  DMA_Cmd(DMA1_Channel2, ENABLE);		// DMA x UPDATE on TIM2

  TIM_Cmd(TIM1, ENABLE);
  TIM_Cmd(TIM2, ENABLE);
}

/*******************************************************************************
* Function Name  : DLED_Service
* Description    : None.
* Input          : None.
* Output         : None.
* Return         : None
*******************************************************************************/

void	DLED_Service(void)
{
	if(TIM2->CNT < dled_buff[8])
	{
		GPIO_ResetBits(PC5);
	}
	else
	{
		GPIO_SetBits(PC5);
	}
}

/*******************************************************************************
* Function Name  : DLED_Init
* Description    : None.
* Input          : None.
* Output         : None.
* Return         : None
*******************************************************************************/

void	DLED_SetIntensity(u8 led, u8 intensity)
{
	if (led >= NR_LED)
		return;

	if (intensity > 99)
		intensity = 99;

	dled_buff[led] = intensity;
}

/*******************************************************************************
* Function Name  : DLED_Disable
* Description    : None.
* Input          : None.
* Output         : None.
* Return         : None
*******************************************************************************/

void	DLED_Disable(void)
{
	for (u8 j=0; j<NR_LED; j++)
	{
		dled_buff[j] = 0;
	}
	TIM_Cmd(TIM1, DISABLE);
	TIM_Cmd(TIM2, DISABLE);
	TIM_SetCompare1(TIM1, 0);
	TIM_SetCompare2(TIM1, 0);
	TIM_SetCompare3(TIM1, 0);
	TIM_SetCompare4(TIM1, 0);
	TIM_SetCompare1(TIM2, 0);
	TIM_SetCompare2(TIM2, 0);
	TIM_SetCompare3(TIM2, 0);
	TIM_SetCompare4(TIM2, 0);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, DISABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | \
												 RCC_APB2Periph_GPIOC | \
												 RCC_APB2Periph_GPIOD | \
												 RCC_APB2Periph_TIM1 | \
												 RCC_APB2Periph_AFIO,
												 ENABLE);
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, DISABLE);

}

/*******************************************************************************
* Function Name  : DLED_Enable
* Description    : None.
* Input          : None.
* Output         : None.
* Return         : None
*******************************************************************************/

void	DLED_Enable(void)
{

	TIM_Cmd(TIM1, ENABLE);
	TIM_Cmd(TIM2, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | \
												 RCC_APB2Periph_GPIOC | \
												 RCC_APB2Periph_GPIOD | \
												 RCC_APB2Periph_TIM1 | \
												 RCC_APB2Periph_AFIO,
												 ENABLE);
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
}

/**** end of file ****/


/*
 * irq.c
 *
 *  Created on: May 8, 2023
 *      Author: BaracchiF
 */

/* Includes ------------------------------------------------------------------*/
#include "ch32v00x.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Extern function prototypes ------------------------------------------------*/

/*** from TMR.C Module ***/
extern void TMR_Irq(void);
/*** from SENS.C Module ***/
extern void	SENS_Irq(void);

/* Private functions ---------------------------------------------------------*/

void SysTick_Handler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void EXTI7_0_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));

/*******************************************************************************
* Function Name  : SysTick_Handler
* Description    : None.
* Input          : None.
* Output         : None.
* Return         : None
*******************************************************************************/

void SysTick_Handler(void)
{
	SysTick->SR = 0x0;
  SysTick->CTLR &= ~0x8000;

  TMR_Irq();

} /* SysTick_Handler */

/*********************************************************************
 * @fn      EXTI0_IRQHandler
 *
 * @brief   This function handles EXTI0 Handler.
 *
 * @return  none
 */
void EXTI7_0_IRQHandler(void)
{
	SENS_Irq();
}

/***** end of IRQ file *****/

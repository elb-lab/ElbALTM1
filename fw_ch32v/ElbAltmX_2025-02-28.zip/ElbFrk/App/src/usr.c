/**
  ******************************************************************************
  * @file           : usr.c
  * @brief          : user program module
  ******************************************************************************
*/

/* Includes ------------------------------------------------------------------*/
#include <stdlib.h>
#include <string.h>
#include "sys.h"
#include "dled.h"
#include "sens.h"
#include "rel.h"

/* Private typedef -----------------------------------------------------------*/

typedef enum BUFFER_STAT_ {
	BUFFER_EMPTY = 0,
	BUFFER_NOT_EMPTY,
} BUFFER_STAT;

/* Private define ------------------------------------------------------------*/

#define STANDBY_DELAY			13000
#define STEP							1

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

u8		pwm_array[NR_LED];
BUFFER_STAT	stat = BUFFER_EMPTY;

/* timers */
tmr		tmr_standby = STANDBY_DELAY;
tmr		tmr_tick = 0;
tmr		tmr_led = 0;
tmr		delay_led = 1000;

/* Private function prototypes -----------------------------------------------*/
/* Extern function prototypes ------------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

static void	standby(void);

/*******************************************************************************
* Function Name  : usr_setup
* Description    : None.
* Input          : None.
* Output         : None.
* Return         : None
*******************************************************************************/

void usr_setup(void)
{
  TMR_Init();
  SENS_Init();
  DLED_Init();

  while(strcmp("ElbFrk", rel.fw_name) != 0);

}

/*******************************************************************************
* Function Name  : usr_main
* Description    : None.
* Input          : None.
* Output         : None.
* Return         : None
*******************************************************************************/

void usr_main(void)
{
	u8 j, led;

//#define __LED_TEST__
#ifdef __LED_TEST__
	while(1)
	{
		for (j=0; j<NR_LED; j++)
		{
			DLED_SetIntensity(j, pwm_array[j]);
		} /* for */
	}
#endif	/* __LED_TEST__ */

  wait(997);
  srand(TIM1->CNT);
  tmrStart(tmr_standby, STANDBY_DELAY);

	while(1)
	{
		DLED_Service();

		if (tmrTick(tmr_tick, 15))
		{
			stat = BUFFER_EMPTY;
			for (j=0; j<NR_LED; j++)
			{
				if (pwm_array[j] > 0)
				{
					if (pwm_array[j] < STEP)
						pwm_array[j] = 0;
					else
						pwm_array[j] -= STEP;
					DLED_SetIntensity(j, pwm_array[j]);
					stat = BUFFER_NOT_EMPTY;
				}
			} /* for */
		} /* tick */

		if(tmr_standby != 0)
		{
			/* led changer */
			if (tmrTick(tmr_led, delay_led))
			{
				led = rand() % NR_LED;
				if (pwm_array[led] == 0)
				{
					pwm_array[led] = 80;
				}
				delay_led = rand() % 100 + 100;
			} /* timer led changer */
			if (SENS_Read())
			{
				tmrStart(tmr_standby, STANDBY_DELAY);
			}
		}
		else if (stat == BUFFER_EMPTY)
		{
			standby();
		  tmrStart(tmr_standby, STANDBY_DELAY);
		}
	} /* while(1) */
} /* usr_main() */

/*******************************************************************************
* Function Name  : usr_main
* Description    : None.
* Input          : None.
* Output         : None.
* Return         : None
*******************************************************************************/
static
void	standby(void)
{
	DLED_Disable();
	wait(5);
	NVIC_DisableIRQ(SysTicK_IRQn);
	__WFE();
	NVIC_EnableIRQ(SysTicK_IRQn);
	wait(5);
	DLED_Init();
}

/***** end of file *****/

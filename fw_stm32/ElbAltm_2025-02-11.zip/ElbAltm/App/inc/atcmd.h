/*
 * atcmd.h
 *
 *  Created on: 13 ott 2020
 *      Author: BaracchiF
 */

#ifndef _ATCMD_H_
#define _ATCMD_H_

void	ATCMD_Init(void);
u8		ATCMD_Service(void);

#endif /* _ATCMD_H_ */

/***** end of file *****/

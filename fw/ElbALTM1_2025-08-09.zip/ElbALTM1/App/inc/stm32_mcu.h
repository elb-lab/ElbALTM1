/*
 * stm32_mcu.h
 *
 *  Created on: Jul 12, 2021
 *      Author: BaracchiF
 */

#ifndef INC_STM32_MCU_H_
#define INC_STM32_MCU_H_

#include "stm32c0xx.h"

#endif /* INC_STM32_MCU_H_ */

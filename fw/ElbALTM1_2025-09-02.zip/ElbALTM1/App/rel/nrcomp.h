/*****************************************************************
 *                C O M P I L E   N U M B E R                     
 *****************************************************************/

#ifndef __NCOMP_H__
#define __NCOMP_H__

#ifdef __cplusplus
extern {
#endif /* __cplusplus */

#define DATA_COMPILE "02/09/25"
#define NR_COMPILE "250902.02"

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __NCOMP_H__ */



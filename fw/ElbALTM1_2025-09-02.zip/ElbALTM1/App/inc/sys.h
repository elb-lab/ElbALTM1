/*
 * stm32_mcu.h
 *
 *  Created on: Jul 12, 2021
 *      Author: BaracchiF
 */

#ifndef _SYS_H_
#define _SYS_H_

#include "stm32_mcu.h"
#include "stm32_pin.h"
#include "stm32_type.h"

#endif /* _SYS_H_ */
